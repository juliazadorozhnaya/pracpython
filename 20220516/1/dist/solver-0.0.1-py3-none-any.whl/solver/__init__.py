def solve(a:float, b: float):
    if a == 0:
        return None
    return -b / a